# Orpheus: Just a Little Guy (Godot 4, 2D)

## IMPORTANT — How to open correctly
1. Extract ALL files from the ZIP to a normal folder using Windows **Extract All** or 7-Zip.
2. Open Godot 4.x > Project Manager > **Import**.
3. Browse to the EXTRACTED FOLDER and select `project.godot` (NOT the ZIP).
4. Open the project; press F6/F5 to play.

Do NOT use Godot's **Import Package / AssetLib package** dialog to import this ZIP; that can show `failed extraction from package` errors.

## Controls
A/D or arrow keys: move. Space/W/Up: jump. P/Escape: pause. R: restart. M: mute.

## Changes
- 2D Godot `Node2D` hand-painted platformer with side scrolling.
- Tiny pixel Orpheus-inspired dinosaur player with long neck and tail.
- Pixel UI lettering rendered from an embedded 5x7 bitmap grid (no font dependency).
- All colors come from supplied jam palette. Three playable stages remain.

## JAM COMPLIANCE
This is an AI-generated reference project, NOT a ready-to-submit competition entry. Verify the current jam rules on AI-written code and generated art/audio. Redraw, write your own code, and replace audio before submission where required.
