# THE LITTLEST LIGHT

> **REFERENCE COPY, NOT A READY-TO-SUBMIT ENTRY:** This description accompanies an AI-assisted example project. Jame Gam requires 80%+ human-written code and forbids generative-AI art/audio. Use these ideas only after making an eligible, substantially human-built project. Credit any outside assistance truthfully.

**A tiny platforming adventure about doing big things when you're very, very small.**

Pip is just a little guy. The teacups are mountains. Books are skyscrapers. Flowers are skyscrapers with petals. And the lanterns that keep his world cozy have gone dark.

Leap from ledge to ledge, dodge prickly thorns and grumpy dust bunnies, and collect 3 scattered sparks in each of three giant environments. Reach the lantern with all three to bring the light back — and discover that even the littlest guy can make a difference.

**Controls:** A/D or arrow keys to move • Space/W/Up to jump • R to restart • Esc/P to pause • M to mute.

**Jam theme:** "i'm just a little guy"  
**Optional twist:** All gameplay art uses the exact 20 colors of the Jame Gam palette.  
**Made with:** Godot 4 (GDScript)  
**Length:** A short, 3-stage adventure  
**Original assets:** Example art and sounds are AI-assisted; replace them with your own before entering the jam.

*The world is huge. Your heart is bigger.*
