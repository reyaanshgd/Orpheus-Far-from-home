# Jame Gam 2026: make it your own before submitting

Official event/rules: https://itch.io/jam/jame-gam-game-jam

**This entire example project was created with AI assistance. Do not submit it unchanged.** Under the published Jame Gam rules:

- The theme is **"i'm just a little guy"**. The supplied Jame Gam 20-color palette is an optional twist.
- **AI assistance for code is allowed but discouraged, and at most 20% of the final code can be AI-written.** That means you need to write at least 80% of your own final submission code, not merely rename or rearrange this generated source.
- **Generative AI is not allowed for art or audio.** This package's procedural art, cover, icon, and music were produced with AI assistance; treat all as examples and replace with sprites, art and sounds you make yourself. The original supplied palette is provided for reference.
- The game has to run **in a browser or on Windows with no setup**. A zip of source project alone is NOT a playable entry.
- Provide your **source code** (e.g., GitHub). The participant or each team member must be 13–18 and sufficiently involved.
- Make the game during the jam, put real effort into it, credit others' contributions, and rate at least five games.
- Per the official rules, submission closes **Sunday, October 25, 2026 at 5:00 PM Eastern (2:00 PM Pacific)**. Submit on itch.io **and** the separate Hack Club form described on the jam page.

## How to build your own compliant version

1. **Design your own twist.** A tiny snail who can hide under acorns, a small bug who helps a big robot, or a mouse rearranging massive objects would make the game more personal. Write down your own mechanics, levels, and win condition.
2. **Create your own Godot scene and scripts.** Read this reference's constants, input, collision, and draw routines to learn the approach, but implement your own movement, collectibles, hazards, levels, and UI. Do not copy the entire `scripts/game.gd` and claim authorship. Keep personal notes/commits so you know what you built.
3. **Create your own art** with Godot drawing tools, Aseprite, LibreSprite, Krita, or pixel art inside Godot. Use the 20 supplied palette colors. Do not submit the AI-assisted `art/icon.png`, `art/cover.png`, or procedurally drawn game artwork unchanged.
4. **Make your own sounds/music**, record them, or use permitted third-party assets with credits if jam rules allow. Do not submit the AI-assisted WAV files as original human-made art/audio.
5. **Test, fix and export.** Run with Godot (F5), and make a Web or Windows build. A Web export from Godot requires export templates. Then upload and test the itch.io build from a fresh browser. Share your GitHub or other source-code link.

The best entry is a small one you understand and can proudly describe, even if it has only one highly polished level.
