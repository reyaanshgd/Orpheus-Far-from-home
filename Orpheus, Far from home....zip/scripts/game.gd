extends Node2D
## ORPHEUS: LITTLE GUY
## Original 3-stage arcade platformer for Hack Club's Jame Gam.
## All artwork is rendered with the twenty colors in the provided palette.

const W = 960.0
const H = 540.0
const FLOOR_Y = 469.0
const SPEED = 245.0
const ACCEL = 1300.0
const FRICTION = 1700.0
const GRAVITY = 1160.0
const JUMP_VELOCITY = -475.0
const BODY_HALF = 10.0

# The complete 2 x 10 Jame Gam palette (sampled from the uploaded image).
const C_WHITE = Color("#FCFBFC")
const C_CLOUD = Color("#D9D4D8")
const C_PINK = Color("#DB9692")
const C_PEACH = Color("#DCAF91")
const C_YELLOW = Color("#DBD991")
const C_MINT = Color("#96DB91")
const C_SKY = Color("#92B5DB")
const C_LAVENDER = Color("#9196DB")
const C_LILAC = Color("#B991DC")
const C_BLUSH = Color("#DB91D3")
const C_STONE = Color("#514D4A")
const C_INK = Color("#2D2730")
const C_BERRY = Color("#905677")
const C_CLAY = Color("#9E696B")
const C_FERN = Color("#6DA16D")
const C_TEAL = Color("#009C89")
const C_SLATE = Color("#5D719A")
const C_BLUE = Color("#415E9B")
const C_DEEP = Color("#4F62A7")
const C_PURPLE = Color("#735FB1")

const STAGES = [
	{
		"name": "01  /  THE TEACUP",
		"intro": "The smallest things get lost in big places.",
		"outro": "A little light makes the kitchen feel warm.",
		"width": 2470.0,
		"platforms": [Vector3(206, 388, 190), Vector3(464, 323, 184),
			Vector3(718, 385, 209), Vector3(946, 324, 207),
			Vector3(1271, 389, 190), Vector3(1482, 321, 209),
			Vector3(1753, 388, 198), Vector3(1970, 326, 185)],
		"sparks": [Vector2(309, 347), Vector2(1033, 280), Vector2(1592, 280)],
		"thorns": [Vector2(571, 55), Vector2(1181, 66), Vector2(1845, 55)],
		"bugs": [Vector3(850, 65, 1.25), Vector3(1710, 57, 1.35)],
		"checkpoints": [890.0, 1745.0],
		"props": [Vector3(610, 0, 0), Vector3(1190, 1, 0), Vector3(1900, 2, 0)]
	},
	{
		"name": "02  /  THE BOOKSHELF",
		"intro": "Even mountains are made of little steps.",
		"outro": "A little light makes the whole room shine.",
		"width": 2750.0,
		"platforms": [Vector3(178, 384, 184), Vector3(405, 322, 192),
			Vector3(691, 383, 177), Vector3(856, 314, 187),
			Vector3(1130, 389, 191), Vector3(1295, 322, 210),
			Vector3(1552, 379, 203), Vector3(1794, 312, 200),
			Vector3(2087, 382, 192), Vector3(2272, 318, 189)],
		"sparks": [Vector2(482, 281), Vector2(1405, 281), Vector2(1907, 274)],
		"thorns": [Vector2(643, 74), Vector2(1110, 60), Vector2(1660, 65), Vector2(2144, 65)],
		"bugs": [Vector3(806, 82, 1.4), Vector3(1530, 80, 1.85), Vector3(2245, 55, 1.35)],
		"checkpoints": [935.0, 1790.0],
		"props": [Vector3(570, 3, 0), Vector3(1320, 4, 0), Vector3(2200, 3, 0)]
	},
	{
		"name": "03  /  THE BIG GARDEN",
		"intro": "Sometimes courage is just taking one more step.",
		"outro": "You did it. The night is full of light.",
		"width": 2950.0,
		"platforms": [Vector3(179, 389, 190), Vector3(409, 324, 187),
			Vector3(683, 386, 194), Vector3(875, 319, 184),
			Vector3(1121, 380, 199), Vector3(1325, 312, 209),
			Vector3(1628, 381, 188), Vector3(1804, 314, 197),
			Vector3(2089, 388, 204), Vector3(2294, 324, 203),
			Vector3(2512, 383, 165)],
		"sparks": [Vector2(500, 284), Vector2(1426, 270), Vector2(2378, 284)],
		"thorns": [Vector2(601, 77), Vector2(1080, 63), Vector2(1593, 72), Vector2(2025, 62), Vector2(2588, 61)],
		"bugs": [Vector3(785, 75, 1.8), Vector3(1250, 60, 1.55), Vector3(1740, 79, 2.0), Vector3(2480, 69, 1.55)],
		"checkpoints": [964.0, 1904.0],
		"props": [Vector3(548, 5, 0), Vector3(1430, 6, 0), Vector3(2320, 5, 0)]
	}
]

var state := "title" # title | playing | interlude | dead | win | paused
var stage_index := 0
var player := Vector2(80.0, FLOOR_Y)
var velocity := Vector2.ZERO
var on_ground := true
var facing := 1.0
var walk_cycle := 0.0
var jump_was_down := false
var jump_buffer := 0.0
var coyote := 0.0
var hearts := 3
var collected := [false, false, false]
var checkpoint := 80.0
var checkpoint_flags := [false, false]
var invincible := 0.0
var camera_x := 0.0
var camera_shake := 0.0
var world_time := 0.0
var stage_banner := 0.0
var interlude_timer := 0.0
var hover_hint := ""
var particles: Array = []
var muted := false
var touch_active := false
var touch_points: Dictionary = {}
var touch_left := false
var touch_right := false
var touch_jump := false
var sfx: Dictionary = {}
var sound_players: Array[AudioStreamPlayer] = []
var sound_slot := 0
var music_player: AudioStreamPlayer


func _ready() -> void:
	for n in ["jump", "spark", "ouch", "checkpoint", "win", "start"]:
		sfx[n] = load("res://audio/%s.wav" % n)
	for i in range(5):
		var p := AudioStreamPlayer.new()
		p.volume_db = -12.0
		add_child(p)
		sound_players.append(p)
	music_player = AudioStreamPlayer.new()
	music_player.stream = load("res://audio/music.wav")
	music_player.volume_db = -23.0
	add_child(music_player)
	var wav := music_player.stream as AudioStreamWAV
	if wav != null:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
	music_player.play()
	queue_redraw()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_M:
				muted = not muted
				music_player.stream_paused = muted
			KEY_ESCAPE, KEY_P:
				if state == "playing":
					state = "paused"
				elif state == "paused":
					state = "playing"
			KEY_R:
				if state == "playing" or state == "dead" or state == "paused":
					start_stage(stage_index)
			KEY_ENTER, KEY_KP_ENTER, KEY_SPACE:
				if state == "title" or state == "win":
					start_stage(0)
				elif state == "dead":
					start_stage(stage_index)
				elif state == "paused":
					state = "playing"
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if state == "title" or state == "win":
			start_stage(0)
		elif state == "dead":
			start_stage(stage_index)
		elif state == "paused":
			state = "playing"
	if event is InputEventScreenTouch:
		touch_active = true
		if state == "title" or state == "win":
			if event.pressed:
				start_stage(0)
		elif state == "dead" or state == "paused":
			if event.pressed:
				start_stage(stage_index)
		else:
			update_touch_buttons(event.index, event.position, event.pressed)
	if event is InputEventScreenDrag:
		touch_active = true
		if state == "playing":
			update_touch_buttons(event.index, event.position, true)


func update_touch_buttons(index: int, pos: Vector2, down: bool) -> void:
	# Multi-touch is supported: one finger moves while another jumps.
	if down:
		touch_points[index] = pos
	else:
		touch_points.erase(index)
	touch_left = false
	touch_right = false
	touch_jump = false
	for pt in touch_points.values():
		touch_left = touch_left or (pt.x < 130.0 and pt.y > 375.0)
		touch_right = touch_right or (pt.x >= 130.0 and pt.x < 260.0 and pt.y > 375.0)
		touch_jump = touch_jump or (pt.x > 750.0 and pt.y > 365.0)


func start_stage(index: int) -> void:
	stage_index = index
	state = "playing"
	touch_points.clear()
	touch_left = false
	touch_right = false
	touch_jump = false
	player = Vector2(80.0, FLOOR_Y)
	velocity = Vector2.ZERO
	on_ground = true
	facing = 1.0
	walk_cycle = 0.0
	jump_was_down = true # don't carry title keypress over into a jump
	jump_buffer = 0.0
	coyote = 0.0
	hearts = 3
	collected = [false, false, false]
	checkpoint = 80.0
	checkpoint_flags = [false, false]
	invincible = 0.0
	camera_x = 0.0
	camera_shake = 0.0
	stage_banner = 2.7
	particles.clear()
	play_sound("start")
	queue_redraw()


func play_sound(sound_name: String) -> void:
	if muted or not sfx.has(sound_name):
		return
	var p: AudioStreamPlayer = sound_players[sound_slot]
	sound_slot = (sound_slot + 1) % sound_players.size()
	p.stream = sfx[sound_name]
	p.play()


func _physics_process(delta: float) -> void:
	world_time += delta
	if state == "interlude":
		interlude_timer -= delta
		if interlude_timer <= 0.0:
			start_stage(stage_index + 1)
	elif state == "playing":
		advance_player(delta)
		check_pickups_and_hazards()
		stage_banner = maxf(stage_banner - delta, 0.0)
		invincible = maxf(invincible - delta, 0.0)
		var width: float = STAGES[stage_index]["width"]
		var target_cam := clampf(player.x - 250.0, 0.0, width - W)
		camera_x = lerpf(camera_x, target_cam, minf(1.0, 7.0 * delta))
	camera_shake = maxf(0.0, camera_shake - 17.0 * delta)
	for i in range(particles.size() - 1, -1, -1):
		var particle: Dictionary = particles[i]
		particle["life"] -= delta
		particle["pos"] += particle["vel"] * delta
		particle["vel"] *= 0.96
		particles[i] = particle
		if particle["life"] <= 0:
			particles.remove_at(i)
	queue_redraw()


func advance_player(delta: float) -> void:
	var left := Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or touch_left
	var right := Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or touch_right
	var jump_down := Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_SPACE) or touch_jump
	if jump_down and not jump_was_down:
		jump_buffer = 0.14
	jump_was_down = jump_down
	jump_buffer = maxf(0.0, jump_buffer - delta)
	if on_ground:
		coyote = 0.105
	else:
		coyote = maxf(0.0, coyote - delta)
	if jump_buffer > 0.0 and coyote > 0.0:
		velocity.y = JUMP_VELOCITY
		jump_buffer = 0.0
		coyote = 0.0
		on_ground = false
		spawn_particles(player + Vector2(0, -2), C_CLOUD, 6)
		play_sound("jump")
	var direction := int(right) - int(left)
	var goal_speed := float(direction) * SPEED
	var rate := ACCEL if direction != 0 else FRICTION
	velocity.x = move_toward(velocity.x, goal_speed, rate * delta)
	if direction != 0:
		facing = float(direction)
		walk_cycle += delta * absf(velocity.x) * 0.075
	velocity.y = minf(velocity.y + GRAVITY * delta, 850.0)
	var old_y := player.y
	player += velocity * delta
	var max_x: float = STAGES[stage_index]["width"] - 33.0
	player.x = clampf(player.x, 22.0, max_x)
	on_ground = false
	if player.y >= FLOOR_Y and old_y <= FLOOR_Y + 12.0:
		player.y = FLOOR_Y
		velocity.y = 0.0
		on_ground = true
	elif player.y >= FLOOR_Y:
		player.y = FLOOR_Y
		velocity.y = 0.0
		on_ground = true
	if velocity.y >= 0.0:
		for platform in STAGES[stage_index]["platforms"]:
			var x: float = platform.x
			var y: float = platform.y
			var platform_width: float = platform.z
			if old_y <= y + 4.0 and player.y >= y and player.x + BODY_HALF > x and player.x - BODY_HALF < x + platform_width:
				player.y = y
				velocity.y = 0.0
				on_ground = true
				break
	# Let go early for an approachable, controllable little jump.
	if not jump_down and velocity.y < -150.0:
		velocity.y += GRAVITY * 0.68 * delta
	if player.y >= FLOOR_Y and absf(velocity.x) > 55.0 and fmod(walk_cycle, 4.0) < 0.17:
		if randf() < 0.5:
			spawn_particles(player + Vector2(0, -1), C_CLOUD, 1)


func check_pickups_and_hazards() -> void:
	var stage: Dictionary = STAGES[stage_index]
	var sparks: Array = stage["sparks"]
	for i in range(sparks.size()):
		if not collected[i] and (player + Vector2(0, -13)).distance_to(sparks[i]) < 34.0:
			collected[i] = true
			spawn_particles(sparks[i], C_YELLOW, 18)
			play_sound("spark")
	for i in range(2):
		var cp: float = stage["checkpoints"][i]
		if not checkpoint_flags[i] and player.x >= cp:
			checkpoint_flags[i] = true
			checkpoint = cp + 15.0
			spawn_particles(Vector2(cp, FLOOR_Y - 35.0), C_MINT, 14)
			play_sound("checkpoint")
	if invincible <= 0.0:
		for thorn in stage["thorns"]:
			if player.x + 9.0 > thorn.x and player.x - 9.0 < thorn.x + thorn.y and player.y >= FLOOR_Y - 17.0:
				take_hit()
				break
		if invincible <= 0.0:
			for bug in stage["bugs"]:
				var bug_pos := get_bug_pos(bug)
				if absf(player.x - bug_pos.x) < 23.0 and absf((player.y - 14.0) - bug_pos.y) < 21.0:
					take_hit()
					break
	var exit_x: float = stage["width"] - 111.0
	if absf(player.x - exit_x) < 43.0 and player.y > FLOOR_Y - 72.0:
		if collected.all(func(value): return value):
			complete_stage()
		else:
			hover_hint = "The lantern needs all 3 sparks!"
	else:
		hover_hint = ""


func take_hit() -> void:
	hearts -= 1
	invincible = 1.35
	camera_shake = 9.0
	spawn_particles(player + Vector2(0, -12), C_PINK, 12)
	play_sound("ouch")
	if hearts <= 0:
		state = "dead"
	else:
		player = Vector2(checkpoint, FLOOR_Y)
		velocity = Vector2.ZERO
		on_ground = true


func complete_stage() -> void:
	play_sound("win")
	spawn_particles(Vector2(STAGES[stage_index]["width"] - 111.0, 385.0), C_YELLOW, 25)
	if stage_index == STAGES.size() - 1:
		state = "win"
	else:
		state = "interlude"
		interlude_timer = 2.35


func spawn_particles(pos: Vector2, color: Color, count: int) -> void:
	for i in range(count):
		if particles.size() >= 110:
			particles.pop_front()
		particles.append({
			"pos": pos,
			"vel": Vector2(randf_range(-110, 110), randf_range(-155, -35)),
			"life": randf_range(0.25, 0.75),
			"color": color,
			"size": randi_range(2, 5)
		})


func get_bug_pos(bug: Vector3) -> Vector2:
	return Vector2(bug.x + sin(world_time * bug.z) * bug.y, FLOOR_Y - 14.0 + sin(world_time * 2.2 + bug.x) * 3.0)


func _draw() -> void:
	var stage: Dictionary = STAGES[stage_index]
	draw_background(stage)
	var shake := Vector2.ZERO
	if camera_shake > 0.0:
		shake = Vector2(randf_range(-camera_shake, camera_shake), randf_range(-camera_shake * 0.5, camera_shake * 0.5))
	draw_set_transform(Vector2(-roundf(camera_x), 0.0) + shake)
	draw_world(stage)
	if state == "title":
		draw_player(Vector2(145.0, FLOOR_Y), 1.0)
	elif state != "win":
		if invincible <= 0.0 or int(world_time * 16.0) % 2 == 0:
			draw_player(player, 1.0)
	for particle in particles:
		var pp: Vector2 = particle["pos"]
		draw_rect(Rect2(pp.x, pp.y, particle["size"], particle["size"]), particle["color"])
	draw_set_transform(Vector2.ZERO)
	if state != "title":
		draw_hud(stage)
	if state == "title":
		draw_title()
	elif state == "paused":
		draw_modal("JUST A LITTLE BREAK", "Every hero needs a breather.", "ENTER / P / ESC  -  RESUME", "R  -  RESTART LEVEL")
	elif state == "dead":
		draw_modal("LITTLE GUYS TRY AGAIN", "You still have a big heart.", "ENTER / R  -  TRY AGAIN", "YOU'VE GOT THIS!")
	elif state == "interlude":
		draw_modal("ONE SMALL GOOD DEED", STAGES[stage_index]["outro"], "ON TO THE NEXT BIG THING...", "")
	elif state == "win":
		draw_ending()
	elif state == "playing":
		if stage_banner > 0.0:
			draw_stage_banner(stage)
		if hover_hint != "":
			text_center(hover_hint, Vector2(480, 418), 21, C_WHITE)
		if touch_active:
			draw_touch_controls()


func draw_background(stage: Dictionary) -> void:
	var sky: Color = [C_SKY, C_LAVENDER, C_BLUE][stage_index]
	var upper: Color = [C_CLOUD, C_SKY, C_PURPLE][stage_index]
	draw_rect(Rect2(0, 0, W, 230), upper)
	draw_rect(Rect2(0, 208, W, 146), sky)
	draw_rect(Rect2(0, 352, W, 117), [C_PEACH, C_SLATE, C_DEEP][stage_index])
	# Slow parallax silhouette: still only palette colors.
	var parallax := camera_x * 0.21
	for i in range(-2, 11):
		var x := float(i) * 163.0 - fmod(parallax, 163.0)
		var y := 315.0 - float((i * 23 + 21) % 61)
		draw_rect(Rect2(x, y, 117, 170), [C_CLOUD, C_SLATE, C_PURPLE][stage_index])
		if stage_index == 2:
			draw_circle(Vector2(x + 61, y + 19), 40.0, C_DEEP)
	# Large background discs / clouds. These are scenery, not platforms.
	for i in range(-1, 8):
		var x := float(i) * 340.0 + 96.0 - fmod(camera_x * 0.11, 340.0)
		var y := 126.0 + sin(float(i) * 2.5) * 36.0
		draw_circle(Vector2(x, y), 26.0, [C_WHITE, C_CLOUD, C_LILAC][stage_index])
		draw_circle(Vector2(x + 28, y + 4), 23.0, [C_WHITE, C_CLOUD, C_LILAC][stage_index])
		draw_rect(Rect2(x - 1, y + 4, 49, 15), [C_WHITE, C_CLOUD, C_LILAC][stage_index])
	if stage_index == 2:
		# The garden moon.
		draw_circle(Vector2(778.0 - camera_x * 0.08, 104.0), 47.0, C_YELLOW)
		draw_circle(Vector2(800.0 - camera_x * 0.08, 91.0), 40.0, C_BLUE)


func draw_world(stage: Dictionary) -> void:
	var world_width: float = stage["width"]
	# Little points of light and distant blades at floor level.
	for i in range(6, int(world_width / 68.0)):
		var dx := float(i) * 68.0
		if dx > camera_x - 90.0 and dx < camera_x + W + 90.0:
			if stage_index == 2:
				draw_line(Vector2(dx, FLOOR_Y), Vector2(dx + 5, FLOOR_Y - 20 - i % 14), C_FERN, 3)
				draw_line(Vector2(dx + 5, FLOOR_Y - 20 - i % 14), Vector2(dx - 3, FLOOR_Y - 26 - i % 14), C_MINT, 3)
			else:
				draw_rect(Rect2(dx, 443 + i % 8, 8, 4), C_CLOUD if i % 3 == 0 else C_SLATE)
	for prop in stage["props"]:
		if prop.x > camera_x - 350.0 and prop.x < camera_x + 1200.0:
			draw_big_prop(prop)
	# Solid safe floor.
	draw_rect(Rect2(0, FLOOR_Y, world_width, 71), C_INK)
	draw_rect(Rect2(0, FLOOR_Y, world_width, 8), C_STONE if stage_index != 2 else C_FERN)
	for i in range(int(world_width / 36.0)):
		var xx := float(i) * 36.0
		if xx > camera_x - 50.0 and xx < camera_x + W + 50.0:
			draw_rect(Rect2(xx + 9, FLOOR_Y + 25 + i % 13, 10, 3), C_BERRY)
	# Tall, oversized ledges: reachable in one or two little jumps.
	for plat in stage["platforms"]:
		if plat.x < camera_x - 270.0 or plat.x > camera_x + W + 100.0:
			continue
		draw_platform(plat)
	for thorn in stage["thorns"]:
		if thorn.x > camera_x - 100.0 and thorn.x < camera_x + W + 100.0:
			draw_thorns(thorn.x, thorn.y)
	for bug in stage["bugs"]:
		var p := get_bug_pos(bug)
		if p.x > camera_x - 40.0 and p.x < camera_x + W + 40.0:
			draw_bug(p)
	for i in range(2):
		draw_checkpoint(stage["checkpoints"][i], checkpoint_flags[i])
	for i in range(3):
		if not collected[i]:
			draw_spark(stage["sparks"][i], world_time + float(i) * 1.4)
	draw_lantern(world_width - 111.0, collected.all(func(value): return value))


func draw_platform(plat: Vector3) -> void:
	var x := plat.x
	var y := plat.y
	var w := plat.z
	# Big upholstered ledges with a light border and chunky shadows.
	draw_rect(Rect2(x + 8, y + 9, w - 5, 13), C_INK)
	draw_rect(Rect2(x, y, w, 13), [C_PINK, C_LILAC, C_MINT][stage_index])
	draw_rect(Rect2(x, y, w, 4), C_WHITE if stage_index != 2 else C_YELLOW)
	draw_rect(Rect2(x + 17, y + 12, 6, 7), C_BERRY)
	draw_rect(Rect2(x + w - 21, y + 12, 6, 7), C_BERRY)
	for i in range(int(w / 34.0)):
		draw_rect(Rect2(x + 19 + i * 34, y + 7, 14, 2), [C_BERRY, C_BLUE, C_FERN][stage_index])


func draw_thorns(x: float, width: float) -> void:
	draw_rect(Rect2(x, FLOOR_Y - 6, width, 7), C_FERN)
	for i in range(int(width / 15.0)):
		var xx := x + 2.0 + float(i) * 15.0
		draw_colored_polygon(PackedVector2Array([Vector2(xx - 4, FLOOR_Y - 5), Vector2(xx + 4, FLOOR_Y - 28 - (i % 2) * 7), Vector2(xx + 13, FLOOR_Y - 5)]), C_INK)
		draw_colored_polygon(PackedVector2Array([Vector2(xx + 1, FLOOR_Y - 7), Vector2(xx + 4, FLOOR_Y - 22 - (i % 2) * 7), Vector2(xx + 9, FLOOR_Y - 7)]), C_FERN)


func draw_bug(pos: Vector2) -> void:
	# Dust bunnies: cute, fuzzy, but hazardous.
	draw_circle(pos + Vector2(0, 2), 17, C_INK)
	draw_circle(pos, 14, C_BERRY if stage_index < 2 else C_PURPLE)
	for dx in [-13.0, -5.0, 5.0, 13.0]:
		draw_circle(pos + Vector2(dx, -11 - absf(dx) * 0.4), 5, C_BERRY if stage_index < 2 else C_PURPLE)
	for dx in [-5.0, 5.0]:
		draw_rect(Rect2(pos.x + dx - 2, pos.y - 3, 4, 5), C_WHITE)
		draw_rect(Rect2(pos.x + dx - 1, pos.y - 2, 2, 3), C_INK)
	draw_rect(Rect2(pos.x - 3, pos.y + 6, 6, 2), C_PINK)


func draw_spark(pos: Vector2, phase: float) -> void:
	var y := pos.y + sin(phase * 3.1) * 5.0
	draw_circle(Vector2(pos.x, y), 19, C_WHITE)
	draw_circle(Vector2(pos.x, y), 16, C_LILAC)
	draw_diamond(Vector2(pos.x, y), 14, C_YELLOW)
	draw_diamond(Vector2(pos.x - 3, y - 4), 5, C_WHITE)
	for d in [Vector2(-24, 4), Vector2(23, -8), Vector2(4, 26)]:
		draw_rect(Rect2(pos.x + d.x, y + d.y, 4, 4), C_WHITE)


func draw_diamond(pos: Vector2, radius: float, col: Color) -> void:
	draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -radius), pos + Vector2(radius * 0.76, 0), pos + Vector2(0, radius), pos + Vector2(-radius * 0.76, 0)]), col)


func draw_checkpoint(x: float, activated: bool) -> void:
	if x < camera_x - 65.0 or x > camera_x + W + 65.0:
		return
	draw_rect(Rect2(x - 2, FLOOR_Y - 80, 5, 80), C_INK)
	draw_rect(Rect2(x + 2, FLOOR_Y - 77, 6, 8), C_YELLOW)
	draw_colored_polygon(PackedVector2Array([Vector2(x + 8, FLOOR_Y - 72), Vector2(x + 51, FLOOR_Y - 58), Vector2(x + 8, FLOOR_Y - 44)]), C_MINT if activated else C_CLOUD)
	if activated:
		draw_diamond(Vector2(x + 23, FLOOR_Y - 58), 7, C_WHITE)


func draw_lantern(x: float, lit: bool) -> void:
	# Your destination: a huge lamp, tiny hero.
	draw_rect(Rect2(x - 49, FLOOR_Y - 15, 99, 15), C_INK)
	draw_rect(Rect2(x - 8, FLOOR_Y - 114, 16, 100), C_STONE)
	draw_rect(Rect2(x - 30, FLOOR_Y - 120, 60, 66), C_INK)
	draw_rect(Rect2(x - 24, FLOOR_Y - 114, 48, 52), C_YELLOW if lit else C_SLATE)
	draw_rect(Rect2(x - 14, FLOOR_Y - 104, 28, 34), C_WHITE if lit else C_LAVENDER)
	draw_rect(Rect2(x - 35, FLOOR_Y - 125, 70, 9), C_PINK)
	draw_rect(Rect2(x - 18, FLOOR_Y - 141, 36, 16), C_INK)
	if lit:
		for d in [Vector2(-58, -110), Vector2(54, -99), Vector2(0, -161), Vector2(49, -157)]:
			draw_diamond(Vector2(x, FLOOR_Y) + d, 6 + 2 * sin(world_time * 3.0), C_YELLOW)
	else:
		for p in [Vector2(-14, -96), Vector2(14, -96), Vector2(0, -77)]:
			draw_circle(Vector2(x, FLOOR_Y) + p, 3, C_BLUE)


func draw_big_prop(prop: Vector3) -> void:
	var x := prop.x
	var kind := int(prop.y)
	match kind:
		0: # A towering teacup
			draw_rect(Rect2(x - 90, 254, 184, 176), C_WHITE)
			draw_rect(Rect2(x - 98, 257, 201, 21), C_PINK)
			draw_rect(Rect2(x - 72, 301, 133, 5), C_PEACH)
			draw_circle(Vector2(x + 108, 338), 48, C_WHITE)
			draw_circle(Vector2(x + 108, 338), 27, C_PEACH)
			draw_rect(Rect2(x - 121, 427, 263, 14), C_PINK)
			text_line("TEA", Vector2(x - 39, 382), 35, C_BERRY)
		1: # A huge jar of sugar stars
			draw_rect(Rect2(x - 72, 292, 144, 145), C_CLOUD)
			draw_rect(Rect2(x - 76, 269, 152, 28), C_PINK)
			draw_rect(Rect2(x - 67, 302, 16, 111), C_WHITE)
			for i in range(9):
				draw_diamond(Vector2(x - 46 + float(i % 3) * 40, 326 + float(i / 3) * 35), 7, C_YELLOW)
		2: # One enormous spoon
			draw_line(Vector2(x + 13, 268), Vector2(x - 55, 434), C_INK, 21)
			draw_line(Vector2(x + 13, 268), Vector2(x - 55, 434), C_CLOUD, 15)
			draw_circle(Vector2(x + 22, 249), 42, C_CLOUD)
			draw_circle(Vector2(x + 17, 245), 23, C_WHITE)
		3: # Books
			for i in range(5):
				var bx := x - 107 + float(i) * 43
				var top := 248 + float((i * 19) % 64)
				draw_rect(Rect2(bx, top, 38, 431 - top), [C_PINK, C_PURPLE, C_MINT, C_PEACH, C_LAVENDER][i])
				draw_rect(Rect2(bx + 4, top + 15, 4, 50), C_WHITE)
				draw_rect(Rect2(bx + 7, 404, 23, 5), C_INK)
		4: # Stacked giant pencil pot
			draw_rect(Rect2(x - 69, 305, 138, 131), C_PEACH)
			draw_rect(Rect2(x - 75, 303, 150, 16), C_PINK)
			for i in range(5):
				var px := x - 54 + float(i) * 25
				draw_rect(Rect2(px, 228 - i * 6, 12, 90), [C_MINT, C_PINK, C_YELLOW, C_LILAC, C_SKY][i])
				draw_colored_polygon(PackedVector2Array([Vector2(px, 228 - i * 6), Vector2(px + 6, 213 - i * 6), Vector2(px + 12, 228 - i * 6)]), C_INK)
		5: # A colossal flower
			draw_rect(Rect2(x - 9, 284, 19, 158), C_FERN)
			draw_colored_polygon(PackedVector2Array([Vector2(x, 383), Vector2(x - 79, 342), Vector2(x - 48, 399)]), C_MINT)
			draw_colored_polygon(PackedVector2Array([Vector2(x, 363), Vector2(x + 70, 330), Vector2(x + 49, 391)]), C_MINT)
			for i in range(8):
				var a := float(i) * TAU / 8.0
				draw_circle(Vector2(x + cos(a) * 59, 273 + sin(a) * 59), 34, C_PINK if i % 2 == 0 else C_BLUSH)
			draw_circle(Vector2(x, 273), 37, C_YELLOW)
			draw_circle(Vector2(x - 9, 267), 5, C_INK)
			draw_circle(Vector2(x + 9, 267), 5, C_INK)
			draw_arc(Vector2(x, 271), 10, 0.2, 2.9, 12, C_INK, 3)
		6: # Huge toadstool canopy
			draw_rect(Rect2(x - 26, 298, 52, 144), C_CLOUD)
			draw_circle(Vector2(x, 294), 96, C_PINK)
			draw_rect(Rect2(x - 96, 293, 192, 23), C_BERRY)
			for dot in [Vector2(-45, -35), Vector2(19, -56), Vector2(59, -19)]:
				draw_circle(Vector2(x, 294) + dot, 14, C_WHITE)


func pixel_rect(x: float, y: float, w: float, h: float, c: Color) -> void:
	draw_rect(Rect2(roundf(x), roundf(y), roundf(w), roundf(h)), c)


func draw_player(foot: Vector2, scale: float) -> void:
	# Orpheus: a tiny long-necked Hack Club dinosaur drawn entirely in chunky pixels.
	# At normal gameplay scale the body is just 24 pixels wide.
	var s := scale
	var bob := (roundf(sin(walk_cycle * 2.0) * 2.0) if on_ground and absf(velocity.x) > 38.0 else 0.0) * s
	var x := roundf(foot.x)
	var y := roundf(foot.y + bob)
	# Pixel tail behind Orpheus, on the opposite side from the face.
	var d := facing
	pixel_rect(x - 9 * d * s, y - 13 * s, 14 * s, 9 * s, C_INK)
	pixel_rect(x - 19 * d * s, y - 10 * s, 13 * s, 5 * s, C_INK)
	pixel_rect(x - 25 * d * s, y - 7 * s, 9 * s, 4 * s, C_INK)
	pixel_rect(x - 19 * d * s, y - 9 * s, 14 * s, 3 * s, C_MINT)
	# Feet, outlined in dark palette color.
	pixel_rect(x - 9 * s, y - 7 * s, 9 * s, 7 * s, C_INK)
	pixel_rect(x + 3 * s, y - 7 * s, 9 * s, 7 * s, C_INK)
	pixel_rect(x - 7 * s, y - 6 * s, 6 * s, 5 * s, C_FERN)
	pixel_rect(x + 5 * s, y - 6 * s, 6 * s, 5 * s, C_FERN)
	# Round belly and tall neck, with stair-stepped pixel edges.
	pixel_rect(x - 12 * s, y - 24 * s, 25 * s, 18 * s, C_INK)
	pixel_rect(x - 10 * s, y - 23 * s, 21 * s, 15 * s, C_MINT)
	pixel_rect(x + 1 * d * s, y - 42 * s, 11 * s, 23 * s, C_INK)
	pixel_rect(x + 2 * d * s, y - 40 * s, 8 * s, 20 * s, C_MINT)
	# Long friendly snout, rounded off using blocky edges.
	pixel_rect(x - 2 * s, y - 46 * s, 17 * s, 11 * s, C_INK)
	pixel_rect(x - 1 * s, y - 44 * s, 17 * s, 8 * s, C_MINT)
	pixel_rect(x + 8 * d * s, y - 39 * s, 12 * s, 5 * s, C_INK)
	pixel_rect(x + 8 * d * s, y - 39 * s, 10 * s, 3 * s, C_MINT)
	# Friendly single pixel eye and curved-looking pixel smile.
	pixel_rect(x + 7 * d * s, y - 43 * s, 3 * s, 3 * s, C_INK)
	pixel_rect(x + 12 * d * s, y - 35 * s, 5 * s, 2 * s, C_INK)
	# Arm sticking out from the chest.
	pixel_rect(x + 6 * d * s, y - 20 * s, 12 * s, 5 * s, C_INK)
	pixel_rect(x + 8 * d * s, y - 20 * s, 9 * s, 3 * s, C_FERN)
	# Small pink scarf, just like our tiny hero's original accent.
	pixel_rect(x + 1 * d * s, y - 25 * s, 10 * s, 3 * s, C_PINK)


func draw_hud(stage: Dictionary) -> void:
	draw_rect(Rect2(0, 0, W, 57), C_INK)
	draw_rect(Rect2(0, 55, W, 3), C_BERRY)
	draw_rect(Rect2(18, 14, 28, 27), C_MINT)
	draw_rect(Rect2(24, 22, 4, 4), C_INK)
	draw_rect(Rect2(34, 22, 4, 4), C_INK)
	draw_rect(Rect2(28, 33, 8, 3), C_INK)
	text_line(stage["name"], Vector2(62, 35), 22, C_WHITE)
	for i in range(3):
		var pos := Vector2(558 + i * 44, 27)
		draw_diamond(pos, 14, C_YELLOW if collected[i] else C_STONE)
		draw_diamond(pos, 8, C_WHITE if collected[i] else C_BERRY)
	for i in range(3):
		var pos := Vector2(762 + i * 44, 27)
		draw_heart(pos, C_PINK if i < hearts else C_STONE)
	text_line("M: SOUND", Vector2(866, 18), 12, C_CLOUD)
	text_line("ON" if not muted else "OFF", Vector2(896, 38), 12, C_MINT if not muted else C_PINK)
	if state == "playing":
		var stage_width: float = stage["width"]
		draw_rect(Rect2(0, 532, W, 8), C_STONE)
		draw_rect(Rect2(0, 532, W * (player.x / stage_width), 8), C_MINT)


func draw_heart(pos: Vector2, col: Color) -> void:
	draw_circle(pos + Vector2(-6, -3), 7, col)
	draw_circle(pos + Vector2(6, -3), 7, col)
	draw_colored_polygon(PackedVector2Array([pos + Vector2(-13, 0), pos + Vector2(13, 0), pos + Vector2(0, 13)]), col)


func draw_stage_banner(stage: Dictionary) -> void:
	draw_rect(Rect2(192, 74, 576, 76), C_INK)
	draw_rect(Rect2(192, 148, 576, 4), C_PINK)
	text_center(stage["name"], Vector2(480, 106), 25, C_YELLOW)
	text_center(stage["intro"], Vector2(480, 133), 18, C_WHITE)
	if stage_index == 0 and stage_banner > 0.6:
		draw_rect(Rect2(257, 445, 446, 41), C_INK)
		text_center("A/D or arrows: move    SPACE: jump", Vector2(480, 471), 20, C_WHITE)


func draw_title() -> void:
	draw_rect(Rect2(119, 56, 723, 434), C_INK)
	draw_rect(Rect2(119, 56, 723, 6), C_PINK)
	draw_rect(Rect2(119, 483, 723, 7), C_PURPLE)
	text_center("ORPHEUS: LITTLE GUY", Vector2(472, 128), 47, C_YELLOW)
	text_center("i'm just a little guy", Vector2(476, 171), 27, C_PINK)
	text_center("The world is huge. Your heart is bigger.", Vector2(480, 219), 20, C_WHITE)
	# A little hero inside a tall handmade illustration.
	draw_circle(Vector2(473, 292), 56, C_BERRY)
	draw_circle(Vector2(473, 286), 49, C_SKY)
	draw_diamond(Vector2(407, 267), 11, C_YELLOW)
	draw_diamond(Vector2(545, 296), 13, C_YELLOW)
	draw_diamond(Vector2(488, 236), 8, C_YELLOW)
	draw_player(Vector2(470, 343), 2.15)
	text_center("Find 3 lost sparks. Light the giant lantern.", Vector2(478, 379), 19, C_WHITE)
	draw_rect(Rect2(338, 398, 281, 45), C_MINT)
	text_center("PRESS ENTER TO PLAY", Vector2(480, 429), 23, C_INK)
	text_center("MOVE  A / D or arrows       JUMP  SPACE / W / UP", Vector2(478, 463), 16, C_CLOUD)


func draw_modal(headline: String, caption: String, action: String, footnote: String) -> void:
	draw_rect(Rect2(142, 151, 676, 260), C_INK)
	draw_rect(Rect2(142, 151, 676, 6), C_PINK)
	draw_rect(Rect2(142, 405, 676, 6), C_PURPLE)
	text_center(headline, Vector2(480, 219), 36, C_YELLOW)
	text_center(caption, Vector2(480, 269), 22, C_WHITE)
	text_center(action, Vector2(480, 332), 22, C_MINT)
	if footnote != "":
		text_center(footnote, Vector2(480, 366), 16, C_CLOUD)


func draw_ending() -> void:
	draw_rect(Rect2(116, 76, 728, 420), C_INK)
	draw_rect(Rect2(116, 76, 728, 6), C_YELLOW)
	for i in range(10):
		var a := float(i) * TAU / 10.0 + world_time * 0.45
		draw_diamond(Vector2(480, 264) + Vector2(cos(a) * 190.0, sin(a) * 110.0), 9, [C_YELLOW, C_MINT, C_PINK][i % 3])
	text_center("YOU ARE ENOUGH.", Vector2(480, 157), 49, C_YELLOW)
	text_center("It only took one very little guy", Vector2(480, 217), 24, C_WHITE)
	text_center("to make a very big world brighter.", Vector2(480, 248), 24, C_WHITE)
	draw_player(Vector2(477, 363), 2.5)
	text_center("3 lanterns lit. 9 little sparks saved.", Vector2(480, 417), 19, C_MINT)
	text_center("PRESS ENTER TO PLAY AGAIN", Vector2(480, 465), 20, C_PINK)


func draw_touch_controls() -> void:
	for spec in [[75, "<"], [192, ">"], [858, "^"]]:
		var x: float = spec[0]
		draw_circle(Vector2(x, 467), 44, C_INK)
		draw_circle(Vector2(x, 467), 39, C_SLATE)
		text_center(spec[1], Vector2(x, 481), 39, C_WHITE)


const PIXEL_GLYPHS = {
	"A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
	"B": ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
	"C": ["01111", "10000", "10000", "10000", "10000", "10000", "01111"],
	"D": ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
	"E": ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
	"F": ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
	"G": ["01111", "10000", "10000", "10111", "10001", "10001", "01111"],
	"H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
	"I": ["11111", "00100", "00100", "00100", "00100", "00100", "11111"],
	"J": ["00111", "00010", "00010", "00010", "10010", "10010", "01100"],
	"K": ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
	"L": ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
	"M": ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
	"N": ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
	"O": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
	"P": ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
	"Q": ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
	"R": ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
	"S": ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
	"T": ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
	"U": ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
	"V": ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
	"W": ["10001", "10001", "10001", "10101", "10101", "10101", "01010"],
	"X": ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
	"Y": ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
	"Z": ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
	"0": ["01110", "10011", "10101", "10101", "11001", "10001", "01110"],
	"1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
	"2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
	"3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
	"4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
	"5": ["11111", "10000", "10000", "11110", "00001", "00001", "11110"],
	"6": ["01111", "10000", "10000", "11110", "10001", "10001", "01110"],
	"7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
	"8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
	"9": ["01110", "10001", "10001", "01111", "00001", "00001", "11110"],
	".": ["00000", "00000", "00000", "00000", "00000", "00110", "00110"],
	":": ["00000", "00110", "00110", "00000", "00110", "00110", "00000"],
	"!": ["00100", "00100", "00100", "00100", "00100", "00000", "00100"],
	"?": ["01110", "10001", "00001", "00010", "00100", "00000", "00100"],
	"'": ["00100", "00100", "00010", "00000", "00000", "00000", "00000"],
	"/": ["00001", "00001", "00010", "00100", "01000", "10000", "10000"],
	"-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
	">": ["10000", "01000", "00100", "00010", "00100", "01000", "10000"],
	"<": ["00001", "00010", "00100", "01000", "00100", "00010", "00001"],
	"^": ["00100", "01010", "10001", "00000", "00000", "00000", "00000"],
	"+": ["00000", "00100", "00100", "11111", "00100", "00100", "00000"],
}

func pixel_text_width(value: String, size: int) -> float:
	var unit := maxf(1.0, float(size) / 9.0)
	return float(value.length()) * 6.0 * unit

func text_line(value: String, pos: Vector2, size: int, col: Color) -> void:
	var unit := maxf(1.0, float(size) / 9.0)
	var cursor := pos.x
	for letter in value.to_upper():
		var rows: Array = PIXEL_GLYPHS.get(letter, [])
		for row in range(rows.size()):
			for column in range(5):
				if rows[row][column] == "1":
					draw_rect(Rect2(roundf(cursor + column * unit), roundf(pos.y - 7.0 * unit + row * unit), ceilf(unit), ceilf(unit)), col)
		cursor += 6.0 * unit

func text_center(value: String, pos: Vector2, size: int, col: Color) -> void:
	text_line(value, Vector2(pos.x - pixel_text_width(value, size) * 0.5, pos.y), size, col)
